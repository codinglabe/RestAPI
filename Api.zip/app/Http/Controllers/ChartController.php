<?php

namespace App\Http\Controllers;
use App\Models\ChartModel;
use Illuminate\Http\Request;

class ChartController extends Controller
{
    function ChartContoller(){
        $result = ChartModel::all('technology','projects');
        return $result;
    }
}
